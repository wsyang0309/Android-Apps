package com.applaudstudios.android.inventoryApp;

import android.provider.BaseColumns;

/**
 * Created by suyangw on 12/4/16.
 */

public final class DatabaseContract {
    public DatabaseContract() {
    }

    public static abstract class Products implements BaseColumns {
        public static final String TABLE_NAME = "products";
        public static final String COLUMN_NAME_NULLABLE = null;
        public static final String COLUMN_NAME_PRODUCT_NAME = "name";
        public static final String COLUMN_NAME_PRODUCT_PRICE = "price";
        public static final String COLUMN_NAME_PRODUCT_QUANTITY = "quantity";
        public static final String COLUMN_NAME_PRODUCT_SUPPLIER = "supplier";
        public static final String COLUMN_NAME_PRODUCT_IMAGEURI = "imageuri";
    }
}
