package com.example.android.musicplayer;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class LadygagaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ladygaga);

        TextView back = (TextView) findViewById(R.id.ladygaga_back_button);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent = new Intent(LadygagaActivity.this, MainActivity.class);
                startActivity(backIntent);
            }
        });

        ImageView player = (ImageView) findViewById(R.id.ladygaga_play_icon);
        player.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent playerIntent = new Intent(LadygagaActivity.this, PlayerActivity.class);
                startActivity(playerIntent);
            }
        });

        TextView playlist = (TextView) findViewById(R.id.ladygaga_playlist_button);
        playlist.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent playlistIntent = new Intent(LadygagaActivity.this, PlaylistActivity.class);
                startActivity(playlistIntent);
            }
        });


    }
}
