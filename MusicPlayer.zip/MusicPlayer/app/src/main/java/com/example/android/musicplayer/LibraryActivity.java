package com.example.android.musicplayer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class LibraryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);

        TextView back = (TextView) findViewById(R.id.library_back_button);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent = new Intent(LibraryActivity.this, MainActivity.class);
                startActivity(backIntent);
            }
        });

        ImageView player = (ImageView) findViewById(R.id.library_play_icon);
        player.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent playerIntent = new Intent(LibraryActivity.this, PlayerActivity.class);
                startActivity(playerIntent);
            }
        });

        TextView playlist = (TextView) findViewById(R.id.library_playlist_button);
        playlist.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent playlistIntent = new Intent(LibraryActivity.this, PlaylistActivity.class);
                startActivity(playlistIntent);
            }
        });
    }
}
