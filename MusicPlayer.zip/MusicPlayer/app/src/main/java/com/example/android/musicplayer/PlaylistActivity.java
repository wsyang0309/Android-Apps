package com.example.android.musicplayer;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class PlaylistActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);
        TextView back = (TextView) findViewById(R.id.playlist_back_button);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent = new Intent(PlaylistActivity.this, MainActivity.class);
                startActivity(backIntent);
            }
        });

        ImageView player = (ImageView) findViewById(R.id.playlist_play_icon);
        player.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent playerIntent = new Intent(PlaylistActivity.this, PlayerActivity.class);
                startActivity(playerIntent);
            }
        });

        TextView library = (TextView) findViewById(R.id.playlist_library_button);
        library.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent playlistIntent = new Intent(PlaylistActivity.this, LibraryActivity.class);
                startActivity(playlistIntent);
            }
        });
    }
}
