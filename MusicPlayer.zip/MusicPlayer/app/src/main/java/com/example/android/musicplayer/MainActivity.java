package com.example.android.musicplayer;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    ImageView ladygaga = (ImageView) findViewById(R.id.ladyGaga);
    ladygaga.setOnClickListener(new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            Intent ladygagaIntent = new Intent(MainActivity.this, LadygagaActivity.class);
            startActivity(ladygagaIntent);
        }
    });

        ImageView chainsmokers = (ImageView) findViewById(R.id.chainsmokers);
        chainsmokers.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent chainsmokersIntent = new Intent(MainActivity.this, ChainsmokersActivity.class);
                startActivity(chainsmokersIntent);
            }
        });
    TextView library = (TextView) findViewById(R.id.library_button);
        library.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent libraryIntent = new Intent(MainActivity.this, LibraryActivity.class);
                startActivity(libraryIntent);
            }
        });
    ImageView player = (ImageView) findViewById(R.id.play_icon);
        player.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent playerIntent = new Intent(MainActivity.this, PlayerActivity.class);
                startActivity(playerIntent);
            }
        });

        TextView playlist = (TextView) findViewById(R.id.playlist_button);
        playlist.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent playlistIntent = new Intent(MainActivity.this, PlaylistActivity.class);
                startActivity(playlistIntent);
            }
        });
}
}
