package com.example.android.booklisting;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    public static String GOOGLE_BOOKS_SEARCH_URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);

        Button search = (Button) findViewById(R.id.search_button);
        search.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                EditText buyerNameEditText = (EditText) findViewById(R.id.search_edit_text);
                String searchItem = buyerNameEditText.getText().toString();
                GOOGLE_BOOKS_SEARCH_URL = "https://www.googleapis.com/books/v1/volumes?q=" + searchItem;

                Intent bookListingIntent = new Intent(MainActivity.this, BookListingActivity.class);
                startActivity(bookListingIntent);
            }
        });


    }


    public String getURL() {
        return GOOGLE_BOOKS_SEARCH_URL;
    }
}
