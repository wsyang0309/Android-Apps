package com.example.android.booklisting;

import android.app.LoaderManager.LoaderCallbacks;
import android.content.Context;
import android.content.Loader;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class BookListingActivity extends AppCompatActivity implements LoaderCallbacks<List<BookListing>> {

    private static final int BOOKLISTING_LOADER_ID = 1;
    static MainActivity mainActivity = new MainActivity();
    private BookListingAdapter mAdapter;
    private TextView mEmptyStateTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_listing);

        ListView bookListingListView = (ListView) findViewById(R.id.list);

        mAdapter = new BookListingAdapter(this, new ArrayList<BookListing>());

        bookListingListView.setAdapter(mAdapter);

        mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);
        bookListingListView.setEmptyView(mEmptyStateTextView);

        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            android.app.LoaderManager loaderManager = getLoaderManager();
            loaderManager.initLoader(BOOKLISTING_LOADER_ID, null, this);
        }


    }

    @Override
    public Loader<List<BookListing>> onCreateLoader(int i, Bundle bundle) {
        return new BookListingLoader(this, mainActivity.getURL());
    }

    @Override
    public void onLoadFinished(Loader<List<BookListing>> loader, List<BookListing> bookListings) {
        View loadingIndicator = findViewById(R.id.loading_indicator);
        loadingIndicator.setVisibility(View.GONE);
        mEmptyStateTextView.setText("No Books Found !");
        mAdapter.clear();
        if (bookListings != null && !bookListings.isEmpty()) {
            mAdapter.addAll(bookListings);
        }
    }

    @Override
    public void onLoaderReset(Loader<List<BookListing>> loader) {
        mAdapter.clear();
    }
}
