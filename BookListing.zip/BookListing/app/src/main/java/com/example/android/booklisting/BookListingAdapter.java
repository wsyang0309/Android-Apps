package com.example.android.booklisting;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class BookListingAdapter extends ArrayAdapter<BookListing> {


    public BookListingAdapter(Activity context, ArrayList<BookListing> bookListing) {
        super(context, 0, bookListing);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.booklisting_list_item, parent, false);
        }
        BookListing currentListedBook = getItem(position);

        TextView titleTextView = (TextView) listItemView.findViewById(R.id.title);
        String title = currentListedBook.getTitle();
        titleTextView.setText(title);

        TextView subtitleTextView = (TextView) listItemView.findViewById(R.id.subtitle);
        String subtitle = currentListedBook.getSubtitle();
        subtitleTextView.setText(subtitle);

        TextView authorextView = (TextView) listItemView.findViewById(R.id.author);
        String author = currentListedBook.getAuthor();
        authorextView.setText(author);

        return listItemView;
    }

}
