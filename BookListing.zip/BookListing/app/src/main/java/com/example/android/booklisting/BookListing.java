package com.example.android.booklisting;


public class BookListing {

    private String _subtitle;
    private String _title;
    private String _author;

    public BookListing(String title, String subtitle, String author) {
        _subtitle = subtitle;
        _title = title;
        _author = author;
    }

    public String getTitle() {
        return _title;
    }

    public String getSubtitle() {
        return _subtitle;
    }

    public String getAuthor() {
        return _author;
    }


}
