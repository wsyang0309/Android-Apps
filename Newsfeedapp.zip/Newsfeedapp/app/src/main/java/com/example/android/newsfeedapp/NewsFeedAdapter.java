package com.example.android.newsfeedapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class NewsFeedAdapter extends ArrayAdapter<NewsFeed> {


    public NewsFeedAdapter(Activity context, ArrayList<NewsFeed> newsFeed) {
        super(context, 0, newsFeed);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.news_feed_list_item, parent, false);
        }
        NewsFeed currentListedNews = getItem(position);

        TextView titleTextView = (TextView) listItemView.findViewById(R.id.title);
        String title = currentListedNews.getTitleName();
        titleTextView.setText(title);

        TextView sectionTextView = (TextView) listItemView.findViewById(R.id.section);
        String author = currentListedNews.getSectionName();
        sectionTextView.setText(author);

        return listItemView;
    }

}