package com.example.android.newsfeedapp;


public class NewsFeed {

    private String _titleName;
    private String _sectionName;
    private String _Url;

    public NewsFeed(String titleName, String sectionName, String Url) {
        _titleName = titleName;
        _sectionName = sectionName;
        _Url = Url;
    }

    public String getTitleName() {
        return _titleName;
    }

    public String getSectionName() {
        return _sectionName;
    }

    public String getUrl() {
        return _Url;
    }

}